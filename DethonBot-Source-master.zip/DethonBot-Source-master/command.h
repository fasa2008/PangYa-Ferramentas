#ifndef __COMMAND_H_
#define __COMMAND_H_

#include "library.h"
#include "connect.h"
#include "game_server.h"
#include "room.h"

void CommandAccess(char *commandline);

#endif
